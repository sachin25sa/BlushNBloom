# BloomBid
A ecommerce website for buying and bidding flowers built using Django
